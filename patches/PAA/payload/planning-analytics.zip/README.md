# IBM Bob Planning Analytics Appliance

**PAA-3.0.0 | IBM Bob Shell 2.x | eighth use-case appliance**

Start `./xLaunchpad.sh` for the original menu, interactive sessions, Ask, Code,
Advance/Design and workspace-aware Resume. `--preview`, `--ui-preview` and
`--self-check` are local and do not require Bob. `--doctor` inspects the installed
Bob 2.x CLI; `--auth-check` runs real authentication. Configure Bob credentials in
`.env`; keep TM1/SaaS service credentials separate.

All local file contents are editable. There is no historical receipt, baseline
hash, or exact-permission admission requirement. The repository maintenance.sh
normalizes the selected use-case tree to 0777 and preserves existing contents.
Use `.bob/PAA-MAINTENANCE-POLICY.md` for the exact scope.

## Primary modes

- `ask`: IBM Bob Planning Analytics Ask Appliance.
- `code`: IBM Bob Planning Analytics Code Appliance.
- `advance`: IBM Bob Planning Analytics Advance Appliance.

The complete 20-mode registry includes TM1 modeling, TI, Workspace/Excel, Cloud/SaaS,
Local, containers, security, operations, forecasting and shared development roles.
Design Markdown goes under `bob-planning-analytics-designs/`. Implementation,
validation artifacts and results go under `bob-planning-analytics-store/`.

Read AGENTS.md, `.bob/PAA-DOMAIN-POLICY.md`, the selected rules and skill before
product work. Cloud, SaaS, Local, TM1 11/12 and Software Hub/Certified Containers
are distinct targets. The original guide and reference catalog are in
`.bob/planning-analytics-knowledgebase/`; authored runbooks are separate.

Cyan ANSI input/footer styling is active in `.bob/bob-v2.env`. Browse/Search/KB
responses are used internally while recognized raw terminal payloads are hidden.
The original colored menu and benchmark-derived authentication/TLS are retained.
Use the repository's README and BUILD-REPORT for verification and boundaries.
